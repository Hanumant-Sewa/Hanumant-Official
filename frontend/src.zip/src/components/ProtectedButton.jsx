import React from "react";
import { useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { useAuth } from "../context/AuthContext";

function ProtectedButton({ to, className, children, ...props }) {
  const navigate = useNavigate();
  const { user, loading } = useAuth();

  const handleClick = (e) => {
    e.preventDefault();

    // Wait until authentication status is checked
    if (loading) {
      return;
    }

    // User is not logged in
    if (!user) {
      Swal.fire({
        title: "Login Required",
        text: "Please login first to continue.",
        icon: "warning",
        confirmButtonText: "Go to Login",
        showCancelButton: true,
        cancelButtonText: "Cancel",

        // Hanumat Seva theme
        background: "#fffaf3",
        color: "#3b2a1f",

        confirmButtonColor: "#e87524",
        cancelButtonColor: "#8b6f5a",

        buttonsStyling: true,

        customClass: {
          popup: "hanumat-swal-popup",
          title: "hanumat-swal-title",
          htmlContainer: "hanumat-swal-text",
          confirmButton: "hanumat-swal-confirm",
          cancelButton: "hanumat-swal-cancel",
        },
      }).then((result) => {
        if (result.isConfirmed) {
          navigate("/login", {
            state: {
              intendedPage: to,
            },
          });
        }
      });

      return;
    }

    // User is authenticated
    navigate(to);
  };

  return (
    <button
      type="button"
      className={className}
      onClick={handleClick}
      {...props}
    >
      {children}
    </button>
  );
}

export default ProtectedButton;
